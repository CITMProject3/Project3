Carlos has done this! 

In order to properly serialize primitives, I have changed primitives names to unsigned ints. This codification
appears within a map on CreatePrimitive (ModuleGOManager.cpp)

prim_codes[P_CUBE] = 2147000001;
prim_codes[P_CYLINDER] = 2147000002;
prim_codes[P_PLANE] = 2147000003;
prim_codes[P_SPHERE] = 2147000004;

Be careful when modifying it! 